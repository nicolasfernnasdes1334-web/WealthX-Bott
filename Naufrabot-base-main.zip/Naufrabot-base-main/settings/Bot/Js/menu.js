const Menu = ( timeFt , Bot , sender , groupName  , groupMembers ) => {  
return `
   『 𝐌𝐄𝐍𝐔 - 𝐏𝐑𝐈𝐍𝐂𝐈𝐏𝐀𝐋 』
╭══════════════════
│❐   ➢${timeFt} , 
 ❱  〄 @${sender.split('@')[0]} 
│❐  ꦿ𝐒𝐎𝐘 : ${Bot}
│❐  ꦿ𝙋𝙍𝙀𝙁𝙄𝙅𝙊 : 𝐌𝐮𝐥𝐭𝐢𝐩𝐫𝐞𝐟𝐢𝐣𝐨
│❐  ꦿ𝙂𝙍𝙐𝙋𝙊 : ${groupName}
┃╭───────────────❍
┃│❍ᴄᴏᴍᴏ ᴘᴇʀᴢᴏɴᴀʟɪᴢᴀʀ ᴇʟ ʙᴏᴛ 👇
┃│https://youtube.com/playlist?list=PLsjiVxv1dUKw1bKCmvj43AuUDYOm8ghPF&si=w0Fp_JLXcF8024x8
┃╰───────────────❍
╰━━━━━─「✪」─━━━━━
✪  𝙇𝙄𝙎𝙏𝘼 𝘿𝙀 𝘾𝙊𝙈𝘼𝙉𝘿𝙊𝙎
  ━━━━━─「✪」─━━━━━
╭
   ❍ 𝐌𝐄𝐍𝐔 𝐀𝐃𝐌𝐈𝐍  ❐
╰  
 ❱➢  〄welcome 1/0
 ❱➢  〄antilink 1/0      
 ❱➢  〄modoadmin 1/0
 ❱➢  〄todos
 ❱➢  〄anuncio
 ❱➢  〄ban
 ❱➢  〄kick
 ❱➢  〄notify
 ❱➢  〄rankrep
 ❱➢  〄rankcoins
 ❱➢  〄ranknivel
 
╭
    ❍ 𝐌𝐄𝐍𝐔 𝐂𝐑𝐄𝐀𝐃𝐎𝐑  ❐
╰  
 ❱➢  〄sercreador
 ❱➢  〄antiprivado            
 ❱➢  〄revelarvisu
 ❱➢  〄reiniciar
 ❱➢  〄bangp
 ❱➢  〄unbangp
 ❱➢  〄boton
 ❱➢  〄botoff
╭
  ❍ 𝐌𝐄𝐍𝐔 𝐃𝐄𝐒𝐂𝐀𝐑𝐆𝐀𝐒  ❐
╰
 ❱➢  〄play
 ❱➢  〄playvideo
 ❱➢  〄tiktokvideo
 ❱➢  〄tiktokaudio           
 ❱➢  〄buscarapk
 ❱➢  〄descargarapk
      
╭
  ❍ 𝐌𝐄𝐍𝐔 𝐈𝐍𝐅𝐎  ❐
╰
 ❱➢  〄ping
 ❱➢  〄perfil
 ❱➢  〄botcompleto        
 ❱➢  〄grupos
 ❱➢  〄canales 
 ❱➢  〄serbot 
                  
╭
   ❍ 𝐌𝐄𝐍𝐔 𝐅𝐈𝐆𝐔𝐒  ❐
╰
 ❱➢  〄sticker
 ❱➢  〄attp
 ❱➢  〄attp2
 ❱➢  〄attp3
 ❱➢  〄Emojimix           
      
╭  
   ❍ 𝐌𝐄𝐍𝐔 𝐇𝐄𝐑𝐑𝐀𝐌𝐈𝐄𝐍𝐓𝐀𝐒  ❐
╰   
 ❱➢  〄toimg
 ❱➢  〄tomp3      
 ❱➢  〄calc
 ❱➢  〄nick      
 ❱➢  〄ia
 ❱➢  〄chatgpt
 

╭                    
   ❍ 𝐌𝐄𝐍𝐔 - 𝐄𝐂𝐎𝐍𝐎𝐌𝐈𝐀  ❐       
╰      
 ❱➢  〄Nivel
 ❱➢  〄perfil
 ❱➢  〄cartera
 ❱➢  〄reg
 ❱➢  〄listreg
 ❱➢  〄ruleta 
 ❱➢  〄levelup
 ❱➢  〄minar
 ❱➢  〄regalar
 ❱➢  〄mireputacion
 ❱➢  〄tragamonedas
 ❱➢  〄dayli   
 ❱➢  〄pescar         
 ❱➢  〄tienda     
 ❱➢  〄casar 
          
`}
module.exports = Menu 


